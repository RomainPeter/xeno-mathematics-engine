- R-1 Surproduction d’obligations
  Létalité: Medium
  Mitigation: "Scoring par coût/impact; regrouper; prioriser par standards."
- R-2 Conflits non résolus (UNSAT)
  Létalité: High
  Mitigation: "UNSAT core extractor; arbitrages signés."
- R-3 Couverture conformité < 90%
  Létalité: Medium
  Mitigation: "Gaps + plan de remédiation; itération."
- R-4 Coût audit non réduit
  Létalité: Medium
  Mitigation: "Optimiser Evidence Selector; automatiser exports."
- R-5 Journal volumineux
  Létalité: Low
  Mitigation: "Merkle roots quotidiens; rotation; compression; index."
