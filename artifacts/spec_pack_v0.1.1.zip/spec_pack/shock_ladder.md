S1 (Audit bénin):
- Vérifications non-intrusives: reconstruction, déterminisme, traçabilité, couverture conformité, coût d’audit.
S2 (Incident):
- Gestion d’anomalies: hallucination/contradiction, pertes partielles de journal; objectifs de temps et d’intégrité.
S3 (Adversarial/Enquête):
- Attaques et demandes hostiles: injection contradictoire, contraintes extrêmes, air-gapped parity, blocage des boîtes noires, deny-with-proof.
